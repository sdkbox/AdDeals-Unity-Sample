﻿#include "pch.h"
#include "BridgeBootstrapper.h"

using namespace IL2CPPToDotNetBridge;
using namespace Platform;

