﻿#include "pch.h"
#include "App.h"

using namespace UnityRT;
using namespace Platform;

App::App()
{
}

void App::Start(Windows::UI::Xaml::Controls::SwapChainPanel^ panel)
{
	// AppInit
}
