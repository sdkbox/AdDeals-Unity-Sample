﻿#pragma once

namespace UnityRT
{
    public ref class App sealed
    {
    public:
		App();

		void static Start(Windows::UI::Xaml::Controls::SwapChainPanel^ panel);
    };
}
